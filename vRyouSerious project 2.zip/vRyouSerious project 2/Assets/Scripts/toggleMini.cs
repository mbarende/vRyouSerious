using UnityEngine;
using System.Collections;

public class toggleMini : MonoBehaviour
{


    bool isMini = false;
    bool dimLight = false;
    bool brightenLight = false;

    void Start()
    {
        Cursor.visible = false;
        //StartCoroutine(Dimmer(GameObject.Find("maLight").GetComponent<Light>()));

    }
    void Update()
    {
        if (!isMini)
        {
            if (Input.GetKeyDown(KeyCode.T))
            {
               transform.Find("CharacterModel").gameObject.SetActive(false);


               isMini = true;
               dimLight = true;
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.T))
            {
                transform.Find("CharacterModel").gameObject.SetActive(true);
                isMini = false;
                brightenLight = true;
            }
        }
        if (dimLight && !brightenLight)
        {
            RenderSettings.ambientLight = Color.black;

            Light pl = GameObject.Find("maLight").GetComponent<Light>();
            if (pl.intensity > 0)
            {
                pl.intensity -= .25f;
            }
            else
            {
                dimLight = false;
            }
        }
        if(brightenLight && !dimLight)
        {
            RenderSettings.ambientLight = Color.white;

            Light pl = GameObject.Find("maLight").GetComponent<Light>();

            if(pl.intensity != 8)
            {
                pl.intensity += .25f;
            }
            else { brightenLight = false; }
        }
        
    }

    private IEnumerator Dimmer(Light pl)
    {
        while (true)
        {
            if (Input.GetKeyDown(KeyCode.T))
            {
                while (pl.intensity > 0.1f)
                {
                    pl.intensity = pl.intensity / 1.5f;

                     
                    yield return new WaitForSeconds(0.25f);
                }
            }
        }
    }
}