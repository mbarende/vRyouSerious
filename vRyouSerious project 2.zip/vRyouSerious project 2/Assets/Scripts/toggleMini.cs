using UnityEngine;
using System.Collections;

public class toggleMini : MonoBehaviour
{


    bool isMini = false;
    bool dimLight = false;
    bool brightenLight = false;

    void Start()
    {
        Cursor.visible = false;
        //StartCoroutine(Dimmer(GameObject.Find("maLight").GetComponent<Light>()));

    }
    void Update()
    {
        if (!isMini)
        {
            if (Input.GetKeyDown(KeyCode.T))
            {
               dimLight = true;
               transform.Find("CharacterModel").gameObject.SetActive(false);
        

               
             
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.T))
            {
                dimLight = true;
                transform.Find("CharacterModel").gameObject.SetActive(true);
               
            }
        }
        if (dimLight == true)
        {
            dimLights();
            
           
            
        }
        if (brightenLight)
        {
            brightenLights();
        }
        
    }
    public void dimLights()
    {
        print("x");
        Light pl = GameObject.Find("maLight").GetComponent<Light>();
        if (pl.intensity > 0)
        {
            print("w");
            pl.intensity -= .25f;
        }
        else
        {
            print("y");
            if (!isMini)
            {

                dimLight = false;
                RenderSettings.ambientLight = Color.black;
                transform.position = transform.Find("CharacterModel").transform.position;
                transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                brightenLights();
                isMini = true;
            }else {
                dimLight = false;
                RenderSettings.ambientLight = Color.white;
                transform.position = GameObject.Find("Spawn").transform.position;
                transform.localScale = new Vector3(1f, 1f, 1f);
                isMini = false;
                print("z");
            }
            brightenLights();
        }
    }
    public void brightenLights()
    {
        RenderSettings.ambientLight = Color.white;

        Light pl = GameObject.Find("maLight").GetComponent<Light>();
        
        if (pl.intensity != 8)
        {
            pl.intensity += .25f;
            brightenLight = true;
        }
        else { brightenLight = false; }
    }

    
}